user: 009445384 (Del Castillo, Kyle) 

As per instruction, I have commented out my print/test statements in the Tester files.

I have created a tester/main class for class V2 as it was not provided. Also, I have implemented a vector by vector multiplication as well and not just scalar.

My code has a lot of comments so that it's easier to understand. Please do let me know if it's too much or is annoying to read.
